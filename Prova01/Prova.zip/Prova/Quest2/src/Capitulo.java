
public class Capitulo {
	private int numero;
	private int numeroDePags;
	
	
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public int getNumeroDePags() {
		return numeroDePags;
	}
	public void setNumeroDePags(int numeroDePags) {
		this.numeroDePags = numeroDePags;
	}
	
	
}
